function ener = Ener_1D(t,x,p)


ener = Ener_short(x+t*p,1);
